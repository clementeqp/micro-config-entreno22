package com.auth.srv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthSrvApplicationTests {

	@Test
	void contextLoads() {
	}

}
